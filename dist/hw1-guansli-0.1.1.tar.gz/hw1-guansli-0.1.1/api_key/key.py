# -*- coding: UTF-8 -*-

def get_key():
    k = "beBybSi8daPgsTp5yx5cHtHpYcrjp5Jq"
    return k

if __name__ == '__main__':
    print(get_key())
