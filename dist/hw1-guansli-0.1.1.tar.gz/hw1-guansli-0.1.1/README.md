### Installation

> pip install hw1-guansli

### Get started
How to use this package:

```
from api_key import get_key

k = get_key()
print(k)

```